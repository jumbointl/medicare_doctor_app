

import '../helper/get_req_helper.dart';
import '../model/language_model.dart';
import '../model/language_tran_moel.dart';
import '../utilities/api_content.dart';

class LanguagesService{

  static const  getLngUrl=   ApiContents.getLngUrl;
  static const  getLngTranUrl=   ApiContents.getLngTransUrl;


  static List<LanguageModel> dataFromJson (jsonDecodedData){

    return List<LanguageModel>.from(jsonDecodedData.map((item)=>LanguageModel.fromJson(item)));
  }
  static List<LanguageTranModel> dataFromTransJson (jsonDecodedData){

    return List<LanguageTranModel>.from(jsonDecodedData.map((item)=>LanguageTranModel.fromJson(item)));
  }


  static Future <List<LanguageModel>?> getLngData()async {
    // fetch data
    final res=await GetService.getReq(getLngUrl);

    if(res==null) {
      return null; //check if any null value
    } else {
      List<LanguageModel> dataModelList = dataFromJson(res); // convert all list to model
      return dataModelList;  // return converted data list model
    }
  }

  static Future <List<LanguageTranModel>?> getLngTranData()async {
    final body={"scope":"doctor_app"};
    // fetch data

    final res=await GetService.getReqWithBodY(getLngTranUrl,body);

    if(res==null) {
      return null; //check if any null value
    } else {
      List<LanguageTranModel> dataModelList = dataFromTransJson(res); // convert all list to model
      return dataModelList;  // return converted data list model
    }
  }


}