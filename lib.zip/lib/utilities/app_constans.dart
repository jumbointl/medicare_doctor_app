class AppConstants{
  static const appName="Doctor App"; //current app name
  static const apiKey = "API_KEY_HERE"; //


}