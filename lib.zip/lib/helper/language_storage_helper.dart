import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../model/language_model.dart';
import '../utilities/sharedpreference_constants.dart';

class LanguageStorage {


  static Future<void> saveLanguages(List<LanguageModel> list) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = list.map((e) => e.toJson()).toList();
    prefs.setString(SharedPreferencesConstants.allLanguages, jsonEncode(jsonList));
  }

  static Future<List<LanguageModel>> getLanguages() async {
    final prefs = await SharedPreferences.getInstance();
    final json = prefs.getString(SharedPreferencesConstants.allLanguages);
    if (json == null) return [];

    final List data = jsonDecode(json);
    return data.map((e) => LanguageModel.fromJson(e)).toList();
  }

}
