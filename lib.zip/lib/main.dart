import 'package:doctor_app/service/languages_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import './utilities/app_constans.dart';
import './helper/get_di.dart' as di;
import 'controller/theme_controller.dart';
import 'helper/language_storage_helper.dart';
import 'helper/route_helper.dart';
import 'helper/translation.dart';
import 'theme/dark_theme.dart';
import 'theme/light_theme.dart';
void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await di.init();

  final languages = await LanguagesService.getLngData();
  final translations = await LanguagesService.getLngTranData();

  String lngCode = "en";

  if (languages != null && languages.isNotEmpty) {
    await LanguageStorage.saveLanguages(languages);
    final defaultLang =
    languages.firstWhere((e) => e.isDefault == 1, orElse: () => languages[0]);
    lngCode = defaultLang.code ?? "en";
  }

  if (translations != null && translations.isNotEmpty) {
    for(var tran in translations){
      Translation.load(tran);
    }

  }
  runApp(MyApp( lngCode));

}

class MyApp extends StatelessWidget {
  final String lngCode;
  const MyApp(this.lngCode,{super.key});

  // This widget is the root of application.
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return
      GetBuilder<ThemeController>(builder: (themeController){
        return GetMaterialApp(
          locale:    Locale(lngCode), // translations will be displayed in that locale
          fallbackLocale:  Locale(lngCode), // specify the fallback locale in case an invalid locale is selected.
          translations: Translation(),
          title: AppConstants.appName,
          initialRoute:  RouteHelper.getHomePageRoute(),//RouteHelper.getOnBoardingPageRoute(),//LoginPage(),
          debugShowCheckedModeBanner: false,
          theme: themeController.darkTheme ? dark : light,
          getPages: RouteHelper.routes,
        );
      });
  }
}
